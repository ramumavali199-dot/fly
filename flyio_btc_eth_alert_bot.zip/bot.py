import os
import time
import requests
from telegram import Bot

TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

bot = Bot(token=TOKEN)

def get_price(symbol):
    url = f"https://api.binance.com/api/v3/ticker/price?symbol={symbol}"
    try:
        response = requests.get(url, timeout=5)
        return float(response.json()["price"])
    except Exception as e:
        print(f"Error fetching {symbol}: {e}")
        return None

def main():
    last_prices = {"BTCUSDT": 0, "ETHUSDT": 0}
    threshold = 0.5  # Alert if price changes by 0.5%

    while True:
        for symbol in ["BTCUSDT", "ETHUSDT"]:
            price = get_price(symbol)
            if price:
                last_price = last_prices[symbol]
                if last_price == 0 or abs(price - last_price) / last_price > threshold / 100:
                    msg = f"🔔 {symbol} Price Alert: ${price:.2f}"
                    bot.send_message(chat_id=CHAT_ID, text=msg)
                    last_prices[symbol] = price
                else:
                    print(f"{symbol} stable at {price:.2f}")
        time.sleep(60)

if __name__ == "__main__":
    main()